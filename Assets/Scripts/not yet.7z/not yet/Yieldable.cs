﻿using System;
using System.Collections;
using System.Linq;
using Assets.IL.Scripts.Common.Yieldables;
using Assets.IL.Scripts.Network.Request;
using Assets.IL.Scripts.Network.Response;
using Assets.ILE.Scripts.Network.Request;
using Assets.ILE.Scripts.Settings;
using Assets.Scripts;
using UnityEngine;

namespace Assets.IL.Scripts.Common
{
	/// <summary>
	/// Runs via unity's 'StartCoroutine({this Yieldable})'.
	/// Can be paused, resumed, interrupted, restarted, waited for, and/or yielded.
	/// </summary>
	public abstract class Yieldable : Disposable, IEnumerator
	{
		protected Action Callback;
		// Used to cleanup when this yieldable dies/ends
		public Action<Yieldable> OnDisposeCallback;
		public string ID { get; set; }
		protected bool Paused;
		private bool _setup;
		private bool _isDone;
		private bool _fireCallback = true;

		/// <summary>
		/// Has the yieldable completed its purpose?
		/// </summary>
		/// <returns></returns>
		public abstract bool IsComplete();

		/// <summary>
		/// What should this do when it starts?
		/// </summary>
		public abstract void OnStart();

		/// <summary>
		/// Restart the yieldable 
		/// </summary>
		public abstract void Restart();


		protected override void InternalDispose()
		{
			if (OnDisposeCallback != null)
				OnDisposeCallback(this);
		}

		/// <summary>
		/// Pause a non-complete non-Paused Yieldable
		/// </summary>
		/// <param name="force">Execute regardless if already paused?</param>
		/// <returns>True if successfully paused.</returns>
		public virtual bool Pause(bool force = false)
		{
			if (!force && (_isDone || Paused))
				return false;
			Paused = true;
			// Do your stuff
			return true;
		}

		/// <summary>
		/// Resume a non-complete Paused Yieldable
		/// </summary>
		/// /// <param name="force">Execute regardless if already active?</param>
		/// <returns>True if successfully paused.</returns>
		public virtual bool Resume(bool force = false)
		{
			if (!force && (_isDone || !Paused))
				return false;
			Paused = false;
			// Do your stuff
			return true;
		}

		/// <summary>
		/// Halt the Yieldable and flag it for completion/Disposal
		/// </summary>
		/// <param name="withCallback">Should the interrupted Yieldable fire its callback?</param>
		public virtual void Interupt(bool withCallback = true)
		{
			_fireCallback = withCallback;
			_isDone = true;
		}

		/// <summary>
		/// Has the Yieldable completed and is not paused?
		/// </summary>
		private bool Completed
		{
			get { return IsComplete() && !Paused; }
		}

		/// <summary>
		/// Required for IEnumerator
		/// </summary>
		public void Reset()
		{
			throw new NotImplementedException();
		}

		/// <summary>
		/// Calls OnStart() on first existence and Callbacks + Dispose on its last.
		/// Required for IEnumerator
		/// </summary>
		public bool MoveNext()
		{
			if (_isDone)
			{
				if (_fireCallback && Callback != null)
				{
					Callback();
				}
				Dispose();
			}
			if (!_setup)
			{
				OnStart();
				_setup = true;
			}
			return !_isDone;
		}

		/// <summary>
		/// Polls per frame if the yieldable is completed.
		/// Required for IEnumerator
		/// </summary>
		public object Current
		{
			get
			{
				if (Completed)
					_isDone = true;
				return null;
			}
		}


		public override bool Equals(object obj)
		{
			if (obj == null)
				return false;
			SoundYieldable other = obj as SoundYieldable;
			return other != null && ID == other.ID;
		}

		public bool Equals(SoundYieldable other)
		{
			return other != null && ID == other.ID;
		}

		public static bool operator ==(Yieldable x, Yieldable y)
		{
			if (ReferenceEquals(x, y))
				return true;
			if (ReferenceEquals(x, null) || ReferenceEquals(y, null))
				return false;
			return x.ID == y.ID;
		}

		public static bool operator !=(Yieldable x, Yieldable y)
		{
			return !(x==y);
		}

		public override int GetHashCode()
		{
			return ID.GetHashCode();
		}
	}


	public static class YieldableHelpers
	{
		/// <summary>
		/// Wait for all of the provided Yieldable to complete (in a parallel fashion)
		/// </summary>
		/// <param name="args">Yieldable to wait for</param>
		public static IEnumerator WaitAll(params Yieldable[] args)
		{
			while (args.Any(x => !x.IsComplete()))
				yield return null;
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="relativeUrl">Only provide the relative path of a bundle, the media server will be populated by another server (e.g. buildamonster_root/buildamonster/buildamonster_ds.1)</param>
		/// <param name="hash"></param>
		/// <param name="callback"></param>
		/// <returns></returns>
		public static NetworkRequestYieldable<AssetBundle> AssetBundleYieldable(string relativeUrl, Hash128 hash = default(Hash128), Action<NetworkResponse<AssetBundle>> callback = null)
		{
			var request = new GetAssetBundleRequest(relativeUrl, hash, callback)
			{
				TimeoutTime = Singleton<UnityPreferencesProvider>.Instance.GetInt(PreferenceKeys.MediaTimeout)
			};
			return new NetworkRequestYieldable<AssetBundle>(request);
		}

		public static NetworkRequestYieldable<T> GetRequestYieldable<T>(string url, Action<NetworkResponse<T>> callback = null) where T: class
		{
			var request = new GetRequest<T>(url, callback);
			return new NetworkRequestYieldable<T>(request);
		}
	}


	/// <summary>
	/// When you need a Yieldable that does nothing.
	/// </summary>
	public class NoOpYieldable : Yieldable
	{
		public override bool IsComplete()
		{
			return true;
		}

		public override void OnStart() { }

		public override void Restart() { }
	}
}