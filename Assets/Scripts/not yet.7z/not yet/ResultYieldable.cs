﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.IL.Scripts.Common.Yieldables
{
	public abstract class ResultYieldable<T> : Yieldable
	{
		public abstract T Result { get; }
		public abstract bool Success { get; }
	}

	/// <summary>
	/// When you need a Yieldable that does nothing.
	/// </summary>
	public class NoOpResultYieldable<T> : ResultYieldable<T> where T : class
	{
		public override bool IsComplete()
		{
			return true;
		}

		public override void OnStart() { }

		public override void Restart() { }

		public override T Result
		{
			get { return null; }
		}

		public override bool Success
		{
			get { return true; }
		}
	}
}
