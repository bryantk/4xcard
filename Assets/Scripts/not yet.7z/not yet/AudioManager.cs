﻿using System;
using System.Collections.Generic;
using System.Linq;
using Assets.IL.Scripts.Common;
using Assets.IL.Scripts.Managers;
using Assets.IL.Scripts.Network.Cloud.Session;
using Assets.IL.Scripts.Settings;
using Assets.ILE.Scripts.Settings;
using Assets.Scripts;
using IL.Input;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
	[SerializeField] private AudioSource _instructionSource;
	[SerializeField] private AudioSource _sfxSource;
	[SerializeField] private AudioSource _music1Source;
	[SerializeField] private AudioSource _music2Source;

    public AudioSource InstructionAndSingleSource
    {
        get { return _instructionSource; }
    }

    private float _volumeModifier = 1;

	private static AudioManager _instance;

	public static AudioManager Instance
	{
		get { return _instance; }
	}
	//hash code of audio clip associated with AudioSource, to AudioSource
	private List<SoundYieldable> _multiSoundChannel;
	private SoundYieldable _instructionChannel;
	private SoundYieldable _music1Channel;
	private SoundYieldable _music2Channel;

	private List<AudioClip> _timeoutAudio;
	private readonly SessionData _sessionData = Singleton<SessionData>.Instance;

	public LanguageSupportOptions LanguageSupportOption = LanguageSupportOptions.L1Fade;

	public List<SoundYieldable> ActiveYieldables = new List<SoundYieldable>();

	public event EventHandler<AudioEventArgs> AudioQueued;
    public event EventHandler<ClipPlayedEventArgs> ClipPlayed;

    private readonly Queue<AudioSource> _markedForReset = new Queue<AudioSource>();
	private readonly Queue<SoundYieldable> _markedForStart = new Queue<SoundYieldable>();
	private readonly Queue<SoundYieldable> _markedForPause = new Queue<SoundYieldable>();


	public List<AudioClip> TimeoutAudio
	{
		get { return _timeoutAudio; }
		set
		{
			_timeoutAudio = value;
			ForceTimeout = false;
			TimerManager.Instance.StartTimeOutTimer(_timeoutAudio);
			if (Clickable.InputDisabled)
				TimerManager.Instance.PauseTimeoutTimer();
		}
	}

	private AudioClip[] _translateAudio;

	public AudioClip[] TranslateAudio
	{
		get { return _translateAudio; }
		set { _translateAudio = value; }
	}

	private int _numLoopingSounds;
	private bool _isPaused;

	public bool HasTranslationAudio { get { return _translateAudio != null && _translateAudio.Length > 0; } }

	public bool HasTimeoutAudio { get { return (_timeoutAudio != null && _timeoutAudio.Count > 0) || ForceTimeout; } }


	/// <summary>
	/// Set Volume of all audio (multiplies played audio volume by Volume 0-1)
	/// </summary>
	public float Volume
	{
		get { return _volumeModifier; }
		set { _volumeModifier = value; }
	}

	/// <summary>
	/// Can poll this rather than a callback to know when audio is done.
	/// </summary>
	public bool AudioPlaying
	{
		// Looping 'music' does not count!
		get { return _instructionChannel != null || _multiSoundChannel.Count > 0; }
	}

	public bool ForceTimeout { get; set; }

	/// <summary>
	/// Pauses all audio (non-music).
	/// </summary>
	public void Pause()
	{
		_isPaused = true;
		foreach (var audio in ActiveYieldables)
		{
			audio.Pause();
		}
	}

	/// <summary>
	/// Resumes all audio (non-music).
	/// </summary>
	public void Resume()
	{
		_isPaused = false;
		foreach (var audio in ActiveYieldables)
		{
			audio.Resume();
		}
	}

	private void Awake()
	{
		if (_instance == null)
		{
			_instance = this;
		}
		else
		{
			Destroy(this);
			return;
		}

		_multiSoundChannel = new List<SoundYieldable>();

		GlobalEventManager.Instance.Skip += OnSkip;
		GlobalEventManager.Instance.OnSceneChange += OnSceneChange;
	}

	private void OnSceneChange(object sender, SceneArgs e)
	{
		//old timeout audio will be removed
		TimeoutAudio = null;
	}

	public void RecreateAudioSources()
	{
		_instructionSource = RecreateSource(_instructionSource, "Instruction", false, _instructionChannel);
		_sfxSource = RecreateSource(_sfxSource, "SFX", false, _multiSoundChannel.ToArray());
		_music1Source = RecreateSource(_music1Source, "Music 1", true, _music1Channel);
		_music2Source = RecreateSource(_music2Source, "Music 2", true, _music2Channel);
	}

	private AudioSource RecreateSource(AudioSource source, string name, bool loop, params SoundYieldable[] channels)
	{
		for (var i = 0; i < channels.Length; i++)
		{
			if (channels[i] != null)
			{
				channels[i].Interupt(false);
			}
		}

		var go = source.gameObject;
		Destroy(source);

		var newSource = go.AddComponent<AudioSource>();
		newSource.name = name;
		newSource.loop = loop;

		return newSource;
	}

	private void Start()
	{
		GlobalEventManager.Instance.OnPause += OnPause;
		GlobalEventManager.Instance.OnPauseEnd += OnPauseEnd;
	}

	private void OnPauseEnd(object sender, EventArgs e)
	{
		Resume();
	}

	private void OnPause(object sender, EventArgs e)
	{
		Pause();
	}

	private void OnSkip(object sender, EventArgs eventArgs)
	{
		Interupt();
	}

	/// <summary>
	/// Play a clip as looping Background Music (as many as you want Spencer!). STOP USING THIS!
	/// </summary>
	/// <param name="music"></param>
	/// <param name="volume"></param>
	public void PlayMusic(AudioClip music, float volume = 1)
	{
		PlayAudioOnChannel(music, AudioChannel.LoopingSound, volume);
	}

	public void PauseMusic()
	{
        if (_music1Channel != null)
			_music1Channel.Pause();

		if (_music2Channel != null)
			_music2Channel.Pause();
	}

	public void ResumeMusic()
	{
		if (_music1Channel != null)
			_music1Channel.Resume();

		if (_music2Channel != null)
			_music2Channel.Resume();
	}

	public void StopMusic()
	{
		if (_music1Channel != null)
			_music1Channel.Interupt(false);

		if (_music2Channel != null)
			_music2Channel.Interupt(false);
	}

	/// <summary>
	/// Kill all audio (music and everything else). Attached Callbacks will NOT be fired.
	/// </summary>
	public void StopAll()
	{
		StopMusic();
		foreach (var audio in ActiveYieldables)
		{
			audio.Interupt(false);
		}
	}

	public Yieldable PlayAudioOnChannel(AudioClip clipSource, AudioChannel channel, float volume = 1,
		Action callback = null, Action<AudioSource> audioSourceCallback = null, float pitch = 1)
	{
		return PlayAudioOnChannel(new List<AudioClip> {clipSource}, channel, volume, callback, audioSourceCallback, pitch);
	}

	/// <summary>
	/// Play provided sound.
	/// </summary>
	/// <param name="channel"></param>
	/// <param name="volume"></param>
	/// <param name="callback"></param>
	/// <param name="clips"></param>
	/// <param name="audioSourceCallback"></param>
	public Yieldable PlayAudioOnChannel(List<AudioClip> clips, AudioChannel channel, float volume = 1,
		Action callback = null, Action<AudioSource> audioSourceCallback = null, float pitch = 1, bool isLanguageAudio = false)
	{
		// Copy the list, because it could get destructive
		var clipSource = new List<AudioClip>(clips);
		if (clipSource != null)
			clipSource.RemoveAll(x => x == null || x.length == 0);

		if (clipSource == null || !clipSource.Any())
		{
			Debug.LogWarning("Audio manager - No audio source found!");
			if (audioSourceCallback != null)
				audioSourceCallback(null);
			if (callback != null)
				callback();
			return new NoOpYieldable();
		}

		AudioSource audioSource = null;
		audioSource = GetTargetAudioSource(channel, volume, pitch);

		SoundYieldable yieldable = Create(channel, audioSource, clipSource, volume * _volumeModifier, callback);

		switch (channel)
		{
			case AudioChannel.LoopingSound: //Allow two sounds on the looping channel. 
				if (audioSource == _music1Source)
				{
					KillAudioSource(_music1Channel);
					_music1Channel = yieldable;
				}
				else
				{
					KillAudioSource(_music2Channel);
					_music2Channel = yieldable;
				}
				break;

			case AudioChannel.Instruction: //Stop the instruction channel, only allow one at a time, set the Timeout
				TimeoutAudio = clipSource;
				KillAudioSource(_instructionChannel);
				_instructionChannel = yieldable;

				if (!isLanguageAudio)
				{
					//If instructional audio is played after language specific audio then there is no translatable audio to be replayed
					_translateAudio = null;
				}
				break;

			case AudioChannel.SingleSound: //Single sound plays on the instruction channel; but doesnt do other timeout things
				KillAudioSource(_instructionChannel);
				_instructionChannel = yieldable;
				break;

			case AudioChannel.MultiSound: //Play as many audios as you want. 
				_multiSoundChannel.Add(yieldable);
				break;
		}

		if (audioSourceCallback != null)
			audioSourceCallback(audioSource);

		var args = new AudioEventArgs
		{
			AudioToPlay = clips.ToArray(),
			AudioChannel = channel,
			TranslationAudio = TranslateAudio
		};
		AudioQueued.RaiseEvent(this, args);

		return yieldable;
	}

	/// <summary>
	/// Stops all audio on the provided channel. 
	/// </summary>
	/// <param name="channel"></param>
	public void StopAudioClipOnChannel(AudioChannel channel)
	{
		switch (channel)
		{
			case AudioChannel.Instruction:
				KillAudioSource(_instructionChannel);
				break;
			case AudioChannel.LoopingSound:
				KillAudioSource(_music1Channel);
				KillAudioSource(_music2Channel);
				break;
			case AudioChannel.MultiSound:
				foreach (var audioSource in _multiSoundChannel)
				{
					KillAudioSource(audioSource);
				}
				break;
			case AudioChannel.SingleSound:
				KillAudioSource(_instructionChannel);
				break;
		}
	}

	private AudioSource GetTargetAudioSource(AudioChannel channel, float volume, float pitch = 1)
	{
		AudioSource audioSource = null;

		switch (channel)
		{
			case AudioChannel.Instruction:
			case AudioChannel.SingleSound:
				audioSource = _instructionSource;
				break;

			case AudioChannel.MultiSound:
				// It doesnt make sense to modify the sfx source to get it prepped.
				return _sfxSource;

			case AudioChannel.LoopingSound:
				audioSource = _numLoopingSounds % 2 == 0
					? _music1Source
					: _music2Source;

				_numLoopingSounds++;
				break;
		}

		audioSource.volume = volume * _volumeModifier;
		audioSource.time = 0;
		audioSource.pitch = pitch;
		return audioSource;
	}

	private void KillAudioSource(Yieldable audioSource)
	{
		if (audioSource != null)
		{
			Debug.LogFormat("Stopping audio: ", audioSource.ToString());
			audioSource.Interupt();
		}
}

	/// <summary>
	/// Helper Factory method to create a sound yieldable, start it, and track it.
	/// </summary>
	/// <param name="source">Audio Source to play sound on.</param>
	/// <param name="clip">Audio Clip to play.</param>
	/// <param name="volume"></param>
	/// <param name="callback"></param>
	/// <param name="unique"></param>
	/// <returns></returns>
	private SoundYieldable Create(AudioChannel channel, AudioSource source, List<AudioClip> clips, float volume, Action callback)
	{
		var yieldable = new SoundYieldable(channel, source, clips, callback, RemoveFromTracked);
		ActiveYieldables.Add(yieldable);
		StartCoroutine(yieldable);

		if (_isPaused)
			QueueForPause(yieldable);

		return yieldable;
	}

	private void RemoveFromTracked(SoundYieldable yieldable)
	{
		if (_instructionChannel == yieldable)
			_instructionChannel = null;

		if (_music1Channel == yieldable)
			_music1Channel = null;

		if (_music2Channel == yieldable)
			_music2Channel = null;

		_multiSoundChannel.Remove(yieldable);

		ActiveYieldables.Remove(yieldable);
	}

	/// <summary>
	/// Add source to queue to be killed on the Main thread
	/// </summary>
	/// <param name="source"></param>
	public void QueueForCleanup(AudioSource source)
	{
		_markedForReset.Enqueue(source);
	}

	/// <summary>
	/// Add yieldable to queue to be started on the Main thread
	/// </summary>
	/// <param name="yieldable"></param>
	public void QueueForStart(SoundYieldable yieldable)
	{
		_markedForStart.Enqueue(yieldable);
	}

	public void QueueForPause(SoundYieldable yieldable)
	{
		_markedForPause.Enqueue(yieldable);
	}

	/// <summary>
	/// Used to Marshall Unity related commands to the main thread.
	/// </summary>
	private void Update()
	{
		while (_markedForReset.Count > 0)
		{
			ResetSource(_markedForReset.Dequeue());
		}

		while (_markedForStart.Count > 0)
		{
			_markedForStart.Dequeue().Play();
		}

		while (_markedForPause.Count > 0)
		{
			_markedForPause.Dequeue().Pause();
		}
	}

	/// <summary>
	/// Revert the source to zero state and return to pool.
	/// </summary>
	/// <param name="source"></param>
	private void ResetSource(AudioSource source)
	{
		if (source == null)
		{
			Debug.Log("Tried to reset a destroyed source");
			return;
		}
		//It is possible to stop an audio and then start playing again in the same frame
		//Since the cleanup happens next frame we'll make sure the source isn't playing before reseting it
		//If the source is the sfx source; that just does its own thing
		if(source.isPlaying || source == _sfxSource) return;

		source.Stop();
		source.clip = null;
	}

	/// <summary>
	/// Play audio with language specific options in place
	/// </summary>
	/// <param name="l1clips">Native language audio clips</param>
	/// <param name="l2clips">Most likely going to be English</param>
	/// <param name="channel"></param>
	/// <param name="forceL1"></param>
	/// <param name="callback"></param>
	/// <returns></returns>
	public Yieldable PlayLanguageAudio(AudioClip[] l1clips, AudioClip[] l2clips, AudioChannel channel,
		bool forceL1 = false, Action callback = null)
	{
		var clipsToPlay = new List<AudioClip>();
		var timesThrough = _sessionData.TimesThrough;

		l1clips = l1clips.Where(x => x != null).ToArray();
		l2clips = l2clips.Where(x => x != null).ToArray();

		if (channel == AudioChannel.Instruction)
		{
			// Only modify the translate audio in the instruction channel
			// Make sure we start with it empty
			_translateAudio = null;
		}

		//play audio based on the selected language option
		//If native language is the default language for the product, then LanguageSupportOptions don't matter. 
		var language = _sessionData.SupportLanguage;
		var defaultLanguage = Singleton<ProductSetting>.Instance.DefaultLanguage;
		if (language == defaultLanguage)
		{
			clipsToPlay.AddRange(l2clips);
		}
		else if (forceL1)
		{
			clipsToPlay.AddRange(GetPlayableLanguageAudioWithL2Fallbacks(l1clips, l2clips));
		}
		else
		{
			//see https://github.com/ImagineLearning/UnityClient/wiki/Global-Product-Specifications#language-support
			switch (LanguageSupportOption)
			{
				case LanguageSupportOptions.Immersion:
					//always play English audio which should be L2
					clipsToPlay.AddRange(l2clips);
					break;
				case LanguageSupportOptions.AutotranslateFade:
					//this plays both audio files back to back
					clipsToPlay.AddRange(l2clips);
					clipsToPlay.AddRange(l1clips);
					break;
				// ReSharper disable once RedundantCaseLabel -- I want it to be clear that L1Fade is the default and should generally happen
				case LanguageSupportOptions.L1Fade:
				default:
					clipsToPlay = GetL1FadeClip(l1clips, l2clips, timesThrough, channel);
					break;
			}
		}
		return PlayAudioOnChannel(clipsToPlay, channel, callback: callback, isLanguageAudio: true);
	}

	private List<AudioClip> GetL1FadeClip(AudioClip[] l1clips, AudioClip[] l2clips, int timesThrough, AudioChannel channel)
	{
		var clipsToPlay = new List<AudioClip>();

		var translationFadeTimesThrough = Singleton<ProductSetting>.Instance.TranslationFadeTimesThrough;

		if (timesThrough <= translationFadeTimesThrough)
		{
			//first time play l1 clip if available
			clipsToPlay.AddRange(GetPlayableLanguageAudioWithL2Fallbacks(l1clips, l2clips));
		}
		else
		{
			//play the English instruction but make the translate button clickable
			clipsToPlay.AddRange(l2clips);
			if (channel == AudioChannel.Instruction)
			{
				// Only enable the translation flag for instructional audio.
				_translateAudio = GetPlayableLanguageAudioWithL2Fallbacks(l1clips, l2clips).ToArray();
			}
		}

		return clipsToPlay;
	}

	/// <summary>
	/// This method will replace null L1 audios with L2 audios where we have suitable replacements and remove null entries
	/// </summary>
	/// <param name="l1Clips"></param>
	/// <param name="l2Clips"></param>
	private List<AudioClip> GetPlayableLanguageAudioWithL2Fallbacks(AudioClip[] l1Clips, AudioClip[] l2Clips)
	{
		var length = Mathf.Max(l2Clips.Length, l1Clips.Length);

		var clipsToPlay = new List<AudioClip>(length);

		for (var i = 0; i < length; i++)
		{
			if (i < l1Clips.Length && l1Clips[i] != null)
			{
				clipsToPlay.Add(l1Clips[i]);
			}
			else if (l2Clips[i] != null)
			{
				clipsToPlay.Add(l2Clips[i]);
			}
		}

		clipsToPlay.RemoveAll(x => x == null);
		return clipsToPlay;
	}

	/// <summary>
	/// Halt all audio (sans LoopingChannel) and fire their callbacks now.
	/// </summary>
	public void Interupt()
	{
		// Copy list for we are going to be destructive while iterating
		foreach (var yieldable in ActiveYieldables)
		{
			if (yieldable == _music1Channel || yieldable == _music2Channel)
				continue;

			yieldable.Interupt();
		}
	}

	private void OnDestroy()
	{
		GlobalEventManager.Instance.Skip -= OnSkip;
		GlobalEventManager.Instance.OnPause -= OnPause;
		GlobalEventManager.Instance.OnPauseEnd -= OnPauseEnd;
		GlobalEventManager.Instance.OnSceneChange -= OnSceneChange;
	}

	public void PlayTimeoutAudio()
	{
		if (_timeoutAudio == null || !_timeoutAudio.Any())
		{
			//there is no timeout audio to play
			TimeoutOnAudioFinished(this, EventArgs.Empty);
			return;
		}

		var timeout = (SoundYieldable)PlayAudioOnChannel(TimeoutAudio, AudioChannel.SingleSound);
		timeout.AudioFinished += TimeoutOnAudioFinished;
	}

	private void TimeoutOnAudioFinished(object sender, EventArgs e)
	{
		PlayMakerFSM.BroadcastEvent("TimeoutAudioFinished");
	}

	public void PlayTranslation()
	{
		if (HasTranslationAudio)
		{
			PlayAudioOnChannel(_translateAudio.ToList(), AudioChannel.SingleSound);
		}
		
	}
    public void ClipPlayedRaiseEvent(AudioClip clip, AudioChannel channel)
    {
        if (ClipPlayed != null)
        {
            ClipPlayed.RaiseEvent(this, new ClipPlayedEventArgs {ClipToPlay = clip, AudioChannel = channel});
        }
    }
}

public class AudioEventArgs : EventArgs
{
	public AudioClip[] AudioToPlay;
	public AudioChannel AudioChannel;
	public AudioClip[] TranslationAudio;
}

public class ClipPlayedEventArgs : EventArgs
{
    public AudioClip ClipToPlay;
    public AudioChannel AudioChannel;
}