﻿using System;
using System.Collections.Generic;
using System.Linq;
using Assets.IL.Scripts.Network.Cloud.Session;
using Assets.Scripts;
using Assets.IL.Scripts.Common;
using Assets.Scripts.Cloud.DTO;
using HutongGames.PlayMaker;
using UnityEngine;
using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace IL.Actions.Audio
{
	[ActionCategory("IL-Audio")]
	[Tooltip("Play a sequence of Audios. " + 
			 "Note that it doesn't make sense to play audio sequences on the Looping channel, so it isn't supported." +
			 "If you play it in the Instructional channel, the timeout will be set." +
			 "If you play it in the SingleSound channel, the timeout will not be set. " +
			 "If you play it on the MultiSound channel it will have the same effect as on the SingleSound channel.")]
	public class PlayAudioSequence : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] AudioClips;
		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;

		public FsmBool WaitForCompletion;

		[Tooltip("After this many times through the activity, the audio will no longer wait. 0 = never skip.")]
		public FsmInt RequiredTimes;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		public override void Reset()
		{
			AudioClips = new FsmObject[1];
			Volume = 1;
			WaitForCompletion = true;
			RequiredTimes = 0;
			Channel = AudioChannel.Instruction;
		}

		public override void OnEnter()
		{
			if (AudioClips.Length == 0)
			{
				Debug.LogWarning("Could not find audio in " + Fsm.Name);
				Finish();
				return;
			}

			if ((AudioChannel)Channel.Value == AudioChannel.LoopingSound)
			{
				Debug.LogWarning("Playing an Audio Sequence is not supported on the " + (AudioChannel)Channel.Value + " channel.");
				Finish();
				return;
			}
			List<AudioClip> clips = AudioClips.Where(a => a.Value != null).Select(i => i.Value as AudioClip).ToList();
			bool shouldWait = WaitForCompletion.Value;
			int timesThrough = Singleton<SessionData>.Instance.TimesThrough;
			if (RequiredTimes.Value > 0 && timesThrough > RequiredTimes.Value)
				shouldWait = false;
			if (shouldWait)
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value);
				Finish();
			}
		}
	}

	#region Obsolete Actions
	[Obsolete("Deprecated - use the newer audio things")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Play a sequence of Audios In the given channel. " +
	         "Note that it doesn't make sense to play audio sequences on the Looping channel, so it isn't supported." +
	         "If you play it in the Instructional channel, the timeout will be set." +
	         "If you play it in the SingleSound channel, the timeout will not be set. " +
	         "If you play it on the MultiSound channel it will have the same effect as on the SingleSound channel.")]
	public class PlayAudioSequenceInChannel : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] AudioClips;
		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;

		public FsmBool WaitForCompletion;
		[Tooltip("After this many times through the activity, the audio will no longer wait. 0 = never skip.")]
		public FsmInt RequiredTimes;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;
		public override void Reset()
		{
			AudioClips = new FsmObject[1];
			Volume = 1;
			WaitForCompletion = true;
			RequiredTimes = 0;
		}

		public override void OnEnter()
		{
			if (AudioClips.Length == 0)
			{
				Debug.LogWarning("Could not find audio in " + Fsm.Name);
				Finish();
				return;
			}
			if ((AudioChannel) Channel.Value == AudioChannel.LoopingSound )
			{
				Debug.LogWarning("Playing an Audio Sequence is not supported on the " + (AudioChannel)Channel.Value + " channel.");
				Finish();
				return;
			}
			List<AudioClip> clips = AudioClips.Select(i => i.Value as AudioClip).ToList();
			bool shouldWait = WaitForCompletion.Value;
			int timesThrough = Singleton<SessionData>.Instance.TimesThrough;
			if (RequiredTimes.Value > 0 && timesThrough > RequiredTimes.Value)
				shouldWait = false;
			if (shouldWait)
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value);
				Finish();
			}
		}
	}
#endregion
}
