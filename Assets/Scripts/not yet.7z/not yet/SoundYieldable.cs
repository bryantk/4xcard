﻿using System;
using System.Collections.Generic;
using Assets.IL.Scripts.Network.Cloud.Session;
using Assets.Scripts;
using UnityEngine;

namespace Assets.IL.Scripts.Common
{
	public class SoundYieldable : Yieldable
	{
		private readonly AudioChannel _channel;                        // The "channel" the audio source is to be played on. There is different behavior we need for when the channel is sfx since its a special snowflake.
		private readonly AudioSource _source;                          // The audio source to play the sound on.
		private readonly List<AudioClip> _clips;                       // All the clips for this sequence of audios. Can be a single audio clip.
		private int _currentClipIndex;                                 // The current index if we are an audio sequence; doesnt matter otherwise.
		private float _time;                                           // Used when playing on the sfx channel - since we PlayOneShot on that channel we need an alternative method for detecting end.
		private bool _ready;                                           // There is a slight delay between assigning audio and it starting, this covers for that gap
		private readonly Action<SoundYieldable> _soundDisposeCallback; // This callback is used for helping clean up the audio in AudioManager.
		
		public event EventHandler<EventArgs> AudioFinished;

		public override string ToString()
		{
			if (_clips != null || _clips.Count == 0)
			{
				return "No clips on {0}" + _channel;
			}

			return _currentClipIndex >= _clips.Count
				? _clips[_clips.Count - 1].name + " on " + _channel
				: _clips[_currentClipIndex].name + " on " + _channel;
		}

		public SoundYieldable(AudioChannel channel, AudioSource source, List<AudioClip> clips, Action callback, Action<SoundYieldable> soundDisposeCallback)
		{
			_channel = channel;
			_source = source;
			_clips = clips;
			ID = GenerateUniqueId();
			Callback = callback;
			_soundDisposeCallback = soundDisposeCallback;
		}

		private string GenerateUniqueId()
		{
			return Guid.NewGuid().ToString();
		}

		public override void OnStart()
		{
			if (_clips.Count <= 0)
			{
				// This could happen if the timeout audio is cleared, or an audio sequence is empty
				Debug.LogFormat("Attempted to call a soundYieldable with an empty clip list.");
				_ready = true;
				return;
			}

			Debug.LogFormat("Queueing audioclip for play: {0}; Language: {1}; Channel: {2}", _clips[_currentClipIndex].name, Singleton<SessionData>.Instance.SupportLanguage, _channel);

			// Must do Unity things on Main Thread
			AudioManager.Instance.QueueForStart(this);
		}

		public override bool IsComplete()
		{
			if (_channel == AudioChannel.MultiSound)
			{
				// If we are on the SFX channel, keep track of how much elapsed time since last checked in.
				_time -= Time.deltaTime;

				// The SFX is not done if its not ready to play or the time left is greater than 0.
				// We dont check paused because its handled differently for the SFX channel; it is simply unpaused.
				if (!_ready || _time > 0)
				{
					return false;
				}
			}
			else
			{
				// All other audios are not done when they are playing, Paused, or not yet ready.
				if (_source.isPlaying || Paused || !_ready)
				{
					return false;
				}
			}

			// If source is playing, paused, or not yet started, yield return.
			++_currentClipIndex;
			if (_currentClipIndex >= _clips.Count)
			{
				if (AudioFinished != null)
				{
					AudioFinished.RaiseEvent(this, new EventArgs());
				}
				return true;
			}

			// Reset _ready flag for main thread to play audio and set true.
			_ready = false;

			Debug.LogFormat("Queueing audioclip for play: {0}; Language: {1}; Channel {2}", 
				_clips[_currentClipIndex] == null ? "Unknown" : _clips[_currentClipIndex].name,
				Singleton<SessionData>.Instance.SupportLanguage, _channel);

			AudioManager.Instance.QueueForStart(this);
			return false;
		}

		public void Play()
		{
			// We have a play method invoked from Audio Manager. This ensures that play calls happen from the main thread only.
			// Apparently there is weirdness when doing it in coroutines.

			_ready = true;	// The clip is ready to play

			if (_channel == AudioChannel.MultiSound)
			{
				// The sfx channel uses PlayOneShot. We need to track the time to know when to fire the finished event and clean up.
				// Note that the sfx channel doesnt assign the clip; this is because PlayOneShot doesnt need it.
				_time = _clips[_currentClipIndex].length;
				_source.PlayOneShot(_clips[_currentClipIndex]);
			}
			else
			{
				// All other channels
				_source.clip = _clips[_currentClipIndex];
				_source.Play();
			    AudioManager.Instance.ClipPlayedRaiseEvent(_source.clip, _channel);
			}
		}

		public override bool Pause(bool force = false)
		{
			if (!base.Pause(force))
				return false;

			_source.Pause();
			return true;
		}

		public override bool Resume(bool force = false)
		{
			if (!base.Resume(force))
				return false;

			// The SFX source should not be re-queued for play. It should simply be unpaused.
			// This is because the clip is not assigned to the source, it was called with PlayOneShot; so another Play() call would play the sound again.
			if (_channel == AudioChannel.MultiSound)
				_source.UnPause();
			else
			{
				AudioManager.Instance.QueueForStart(this);
				// For a frame, audio will not be playing, but pause will be false - source is not _ready
				_ready = false;
			}
				
			
			return true;
		}

		protected override void InternalDispose()
		{
			base.InternalDispose();

			// The SFX source should never be modified so it should never be cleaned up.
			// Must do Unity things on Main Thread.
			if (_channel != AudioChannel.MultiSound)
				AudioManager.Instance.QueueForCleanup(_source);

			if (_soundDisposeCallback != null)
				_soundDisposeCallback(this);	// The SFX source should still clean up this yieldable though.
		}

		public override void Restart()
		{
			_source.time = 0;
			Resume(true);
		}

		public override void Interupt(bool withCallback = true)
		{
			_source.Stop();
			if (AudioFinished != null)
			{
				AudioFinished.RaiseEvent(this, new EventArgs());
			}
			base.Interupt(withCallback);
		}
	}
}