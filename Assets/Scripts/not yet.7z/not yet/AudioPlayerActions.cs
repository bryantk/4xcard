﻿using System;
using HutongGames.PlayMaker;
using UnityEngine;
using Tooltip = HutongGames.PlayMaker.TooltipAttribute;

namespace IL.Actions.Audio {

	[ActionCategory("IL-Audio")]
	[@Tooltip("Set the audio on an AudioPlayer's audio source")]
	public class SetAudioPlayerAudio : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioPlayer))]
		public FsmGameObject AudioPlayer;

		[ObjectType(typeof(AudioClip))]
		public FsmObject AudioClip;

		public override void Reset()
		{
			AudioClip = null;
		}

		public override void OnEnter()
		{
			var audioPlayerComponent = AudioPlayer.Value.GetComponent<AudioPlayer>();
			if (audioPlayerComponent == null)
			{
				Debug.LogError("Missing AudioPlayer component in " + Fsm.Name);
				Finish();
				return;
			}
			var audio = AudioClip.Value as AudioClip;
			audioPlayerComponent.GetComponent<AudioSource>().clip = audio;
			audioPlayerComponent.Reset();
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[@Tooltip("Play/pause the audio on an AudioPlayer's audio source")]
	public class PlayAudioPlayerAudio : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioPlayer))]
		public FsmGameObject AudioPlayer;
		[@Tooltip("Whether to wait for the audio to reach the end")]
		public FsmBool Wait;

		private AudioPlayer _audioPlayerComponent;
		public override void Reset()
		{
			Wait = false;
		}

		public override void OnEnter()
		{
			_audioPlayerComponent = AudioPlayer.Value.GetComponent<AudioPlayer>();
			if (_audioPlayerComponent == null)
			{
				Debug.LogError("Missing AudioPlayer component in " + Fsm.Name);
				Finish();
				return;
			}
			_audioPlayerComponent.Play();
			if (Wait.Value)
			{
				_audioPlayerComponent.AudioFinished += AudioFinished;
			}
			else
			{
				Finish();
			}
		}

		private void AudioFinished(object sender, EventArgs eventArgs)
		{
			_audioPlayerComponent.AudioFinished -= AudioFinished;
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[@Tooltip("Pause the audio on an AudioPlayer's audio source")]
	public class PauseAudioPlayerAudio : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioPlayer))]
		public FsmGameObject AudioPlayer;
		public override void OnEnter()
		{
			var audioPlayerComponent = AudioPlayer.Value.GetComponent<AudioPlayer>();
			if (audioPlayerComponent == null)
			{
				Debug.LogError("Missing AudioPlayer component in " + Fsm.Name);
				Finish();
				return;
			}
			audioPlayerComponent.Pause();
			Finish();
		}
	}
}
