﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Assets.IL.Scripts.Common;
using Assets.IL.Scripts.Input;
using HutongGames.PlayMaker;
using UnityEngine;
using Object = UnityEngine.Object;
using Tooltip = HutongGames.PlayMaker.TooltipAttribute;
using Effects = Assets.IL.Scripts.FSMActions.Effects;

namespace IL.Actions.Audio
{
	[Obsolete("Deprecated - use the newer audio things")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Play given audio clip. Clip will be stored for the 'timeout' audio. Deprecated - please use PlayAudioClipInChannel. ")]
	public class PlayAudioClip : FsmStateAction
	{
		[RequiredField] [ObjectType(typeof(AudioClip))] public FsmObject AudioClip;
		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;
		public FsmBool WaitForCompletion;
		[Tooltip("Is this a Sound effect? Then don't tick the timeout audio.")]
		public FsmBool Sfx;
		[Tooltip("Do not log an error if clip not found.")]
        public FsmBool Optional;

        public override void Reset()
		{
			AudioClip = null;
			Volume = 1;
			WaitForCompletion = true;
			Sfx = false;
            Optional = false;
		}

		public override void OnEnter()
		{
		    if (AudioClip.Value == null)
		    {
                if (!Optional.Value)
                    Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
                Finish();
                return;
            }
			var channel = Sfx.Value ? AudioChannel.MultiSound : AudioChannel.Instruction;

			if (WaitForCompletion.Value)
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip, channel, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip, channel, Volume.Value);
				Finish();
			}
		}

	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Play a given clip with language support options.")]
	public class PlayLanguageSpecificAudio : FsmStateAction
	{
		[RequiredField]
		[Tooltip("Audio clip in the student's first or native language (L1).")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject L1AudioClip;

		[RequiredField]
		[Tooltip("Audio clip in the student's second language (L2). Almost always this clip will be in English.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject L2AudioClip;

		[Tooltip("Wait for the audio to finish playing.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("If true, always play the L1 audio if not null")]
		public FsmBool ForceL1;

		public override void Reset()
		{
			L1AudioClip = null;
			L2AudioClip = null;
			WaitForCompletion = true;
			Optional = false;
			ForceL1 = false;
			Channel = AudioChannel.Instruction;
		}

		public override void OnEnter()
		{
			if (L1AudioClip.Value == null && L2AudioClip.Value == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}
			var clip1 = new[] { L1AudioClip.Value as AudioClip};
			var clip2 = new[] { L2AudioClip.Value as AudioClip };
			if (WaitForCompletion.Value)
			{
				AudioManager.Instance.PlayLanguageAudio(clip1, clip2, (AudioChannel)Channel.Value, ForceL1.Value, Finish);
			}
			else
			{
				AudioManager.Instance.PlayLanguageAudio(clip1, clip2, (AudioChannel)Channel.Value, ForceL1.Value);
				Finish();
			}
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Play a given clip and target with language support options.")]
	public class PlayLanguageSpecificAudioWithTarget : FsmStateAction
	{
		[RequiredField]
		[Tooltip("Audio clip in the student's first or native language (L1).")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] L1AudioClips;

		[RequiredField]
		[Tooltip("Audio clip in the student's second language (L2). Almost always this clip will be in English.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] L2AudioClips;

		[Tooltip("Wait for the audio to finish playing.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("If true, always play the L1 audio if not null")]
		public FsmBool ForceL1;

		public override void Reset()
		{
			L1AudioClips = new FsmObject[3];
			L2AudioClips = new FsmObject[2];
			WaitForCompletion = true;
			Optional = false;
			ForceL1 = false;
			Channel = AudioChannel.Instruction;
		}

		public override void OnEnter()
		{
			var L1Clips = L1AudioClips.Where(x => x.Value != null).Select(x => x.Value as AudioClip).ToArray();
			var L2Clips = L2AudioClips.Where(x => x.Value != null).Select(x => x.Value as AudioClip).ToArray();

			if (L1Clips.IsNullOrEmpty() && L2Clips.IsNullOrEmpty())
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}
			if (WaitForCompletion.Value)
			{
				AudioManager.Instance.PlayLanguageAudio(L1Clips, L2Clips, (AudioChannel)Channel.Value, ForceL1.Value, Finish);
			}
			else
			{
				AudioManager.Instance.PlayLanguageAudio(L1Clips, L2Clips, (AudioChannel)Channel.Value, ForceL1.Value);
				Finish();
			}
		}
	}

    [ActionCategory("IL-Audio")]
    [Tooltip("Play an array of given clips with language support options.")]
    public class PlayLanguageAudio : FsmStateAction
    {
        [RequiredField]
        [Tooltip("AudioClips in the student's first or native language (L1). Array must contain objects of type 'AudioClip'")]
        [ArrayEditor(VariableType.Object, elementName: "clip")]
        public FsmArray L1AudioClips;

        [RequiredField]
        [Tooltip("AudioClips in the student's second language (L2). Almost always this clip will be in English. Array must contain objects of type 'AudioClip'")]
        [ArrayEditor(VariableType.Object, elementName: "clip")]
        public FsmArray L2AudioClips;

        [Tooltip("Wait for the audio to finish playing.")]
        public FsmBool WaitForCompletion;

        [Tooltip("Do not log an error if clip not found.")]
        public FsmBool Optional;

        [ObjectType(typeof(AudioChannel))]
        [Tooltip("The channel the audio will be played on.")]
        public FsmEnum Channel;

        [Tooltip("If true, always play the L1 audio if not null")]
        public FsmBool ForceL1;

        public override void Reset()
        {
            L1AudioClips = null;
            L2AudioClips = null;
            WaitForCompletion = true;
            Optional = false;
            ForceL1 = false;
            Channel = AudioChannel.Instruction;
        }

        public override void OnEnter()
        {
            var L1Clips = L1AudioClips.Values.Where(x => x != null).Select(x => x as AudioClip).ToArray();
            var L2Clips = L2AudioClips.Values.Where(x => x != null).Select(x => x as AudioClip).ToArray();

            //If there's something in the arrays and that something isn't an AudioClip
            if ((!L1Clips.IsNullOrEmpty() && !L1AudioClips.Values.All(x => x is AudioClip)) || (!L2Clips.IsNullOrEmpty() && !L2AudioClips.Values.All(x => x is AudioClip)))
            {
                Debug.LogWarning("Could not Play Language Audio because some objects are not of type 'AudioClip' in " + Fsm.Name + " (" + Fsm.ActiveStateName + ")");
                Finish();
                return;
            }

            if (L1Clips.IsNullOrEmpty() && L2Clips.IsNullOrEmpty())
            {
                if (!Optional.Value)
                    Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
                Finish();
                return;
            }
            if (WaitForCompletion.Value)
            {
                AudioManager.Instance.PlayLanguageAudio(L1Clips, L2Clips, (AudioChannel)Channel.Value, ForceL1.Value, Finish);
            }
            else
            {
                AudioManager.Instance.PlayLanguageAudio(L1Clips, L2Clips, (AudioChannel)Channel.Value, ForceL1.Value);
                Finish();
            }
        }
    }

    [ActionCategory("IL-Audio")]
	[Tooltip("Play multiple audio clips and highlight the words in associated text. After one audio ends, highlights continue where it left off." +
		" (See the description for Play Audio Clip In Channel for a description of the different channels available.")]
	public class PlayAudioSequenceWithCuePoints : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The audios to play.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] AudioClips;

		[RequiredField]
		[Tooltip("The text object that will be highlighted")]
		[ObjectType(typeof(SmartText))]
		public FsmObject Text;

		[RequiredField]
		[Tooltip("The json file that contains the cue point information")]
		[ObjectType(typeof(TextAsset))]
		public FsmObject[] CuePointJsons;

		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;

		public FsmBool WaitForCompletion;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

        [Tooltip("The color to use while highlighting based on the cue points. If set to 'None' uses SmartText's default Highlight Color")]
        public FsmColor HighlightColor;

        [Tooltip("Force Sequential Cue Point Processing.")]
        public FsmBool ForceSequential;

        private CuePointHighlighter _highlighter;
		private Queue<AudioClip> _clips;
		private Queue<TextAsset> _cues;
		private SmartText _text;

		public override void Reset()
		{
			AudioClips = null;
			Text = null;
			CuePointJsons = null;
			Volume = 1;
			WaitForCompletion = true;
		    ForceSequential = false;
            HighlightColor = Color.yellow;
            Channel = AudioChannel.Instruction;
		}

		public override void OnEnter()
		{
			if (AudioClips == null || AudioClips.Length == 0)
			{
				Debug.LogWarning("Could not find audio in " + Fsm.Name);
				Finish();
				return;
			}
			if (AudioClips.Length != CuePointJsons.Length)
			{
				Debug.LogWarning("Must have matching number of audios and cuepoint files in " + Fsm.Name);
				Finish();
				return;
			}
			if ((AudioChannel)Channel.Value == AudioChannel.LoopingSound)
			{
				Debug.LogWarning("Playing an Audio Sequence is not supported on the " + (AudioChannel)Channel.Value + " channel.");
				Finish();
				return;
			}
			_clips = new Queue<AudioClip>(AudioClips.Select(i => i.Value as AudioClip));
			_cues = new Queue<TextAsset>(CuePointJsons.Select(i => i.Value as TextAsset));

			_text = (SmartText) Text.Value;
			_highlighter = _text.gameObject.GetOrAddComponent<CuePointHighlighter>();
			// play the first audio...
			PlayNextAudio();

			if (!WaitForCompletion.Value)
				StartCoroutine(WaitNextFrame());
		}

		private void PlayNextAudio()
		{
			if (!_clips.Any())
			{
				Object.Destroy(_highlighter);
				if (WaitForCompletion.Value)
					StartCoroutine(WaitNextFrame());
				return;
			}

			var nextClip = _clips.Dequeue();
			var nextCues = _cues.Dequeue();
			
			// skip empty array elements
			if (nextClip == null)
			{
				PlayNextAudio();
				return;
			}
			// if next cuepoints don't exist, play without them.
			if (nextCues == null)
			{
				AudioManager.Instance.PlayAudioOnChannel(nextClip, (AudioChannel) Channel.Value, Volume.Value, PlayNextAudio);
			}
			else
			{
				_highlighter.enabled = true;
				AudioManager.Instance.PlayAudioOnChannel(nextClip, (AudioChannel) Channel.Value, Volume.Value, PlayNextAudio,
					source => _highlighter.Setup(source, _text, nextCues, false, HighlightColor.IsNone ? ((SmartText)Text.Value).HighlightColor : HighlightColor.Value, ForceSequential.Value));
			}
		}

		private IEnumerator WaitNextFrame()
		{
			yield return null;
			Finish();
		}

	}

    [ActionCategory("IL-Audio")]
	[Tooltip("Play a given clip and highlight the words in associated text. Defaults to the Instruction channel, but can be played on any Channel. " +
		 "Instruction channel allows only 1 audio to play at a time and will set the Timeout audio. " +
		 "LoopingSound channel is good for background music because the audio will loop, and you can play as many tunes as you like. " +
		 "plus the F8 interrupt has no effect on this channel. " +
		 "SingleSound channel allows only 1 audio to play at a time, but will not set the Timeout audio. " +
		 "MultiSound channel allows for many audios to play at a time, but audios are unique, " +
		 "meaning if you try to play the same sound twice at the same time, it will only play once, and no Timeout audio is set.")]
	public class PlayAudioClipWithCuePoints : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The audio to play.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject AudioClip;

		[RequiredField]
		[Tooltip("The text object that will be highlighted")]
		[ObjectType(typeof(SmartText))]
		public FsmObject Text;

		[RequiredField]
		[Tooltip("The json file that contains the cue point information")]
		[ObjectType(typeof(TextAsset))]
		public FsmObject CuePointJson;

		public FsmInt StartIndex = 0;

		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;

		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;


		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("The color to use while highlighting based on the cue points. If set to 'None' uses SmartText's default Highlight Color")]
		public FsmColor HighlightColor;

		[Tooltip("Force Sequential Cue Point Processing.")]
		public FsmBool ForceSequential;

		[Tooltip("Reset the cuepoint highlighter")]
		public FsmBool ResetHighlighter = true;

		[UIHint(UIHint.Variable)]
		[ArrayEditor(VariableType.Int)]
		[Tooltip("Cues to remove prior to highlighting")]
		public FsmArray CuesToRemove;

		private CuePointHighlighter _highlighter;

		public override void Reset()
		{
			AudioClip = null;
			Text = null;
			CuePointJson = null;
			StartIndex = 0;
			Volume = 1;
			WaitForCompletion = true;
			Optional = false;
			ForceSequential = false;
			Channel = AudioChannel.Instruction;
			HighlightColor = Color.yellow;
			ResetHighlighter = true;
			CuesToRemove = null;
		}

		public override void OnEnter()
		{
			if (AudioClip.Value == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}

			var cuesToRemove = CuesToRemove != null && CuesToRemove.Values.Length > 0
				? CuesToRemove.Values.Select(x => (int)x).ToArray()
				: null;
			if (WaitForCompletion.Value)
			{
				var text = (SmartText)Text.Value;
				_highlighter = text.gameObject.GetOrAddComponent<CuePointHighlighter>();
				_highlighter.enabled = true;
				_highlighter.StartIndex = StartIndex.Value;
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip, (AudioChannel)Channel.Value, Volume.Value, Completedaudio,
					source => _highlighter.Setup(source, text, CuePointJson.Value as TextAsset, ResetHighlighter.Value, HighlightColor.IsNone ? ((SmartText)Text.Value).HighlightColor : HighlightColor.Value, ForceSequential.Value, cuesToRemove));
			}
			else
			{
				var text = (SmartText)Text.Value;
				_highlighter = text.gameObject.GetOrAddComponent<CuePointHighlighter>();
				_highlighter.enabled = true;
				_highlighter.StartIndex = StartIndex.Value;
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip, (AudioChannel)Channel.Value, Volume.Value,
					audioSourceCallback: source => _highlighter.Setup(source, text, CuePointJson.Value as TextAsset, ResetHighlighter.Value, HighlightColor.IsNone ? ((SmartText)Text.Value).HighlightColor : HighlightColor.Value, ForceSequential.Value, cuesToRemove));
				Finish();
			}
		}

		private void Completedaudio()
		{
			Finish();
			_highlighter.Unhighlight();
		}

		public override void OnExit()
		{
			if (ResetHighlighter.Value)
			{
				Object.Destroy(_highlighter);
			}
		}
	}

	[Obsolete("Deprecated - use the newer audio things")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Deprecated - please use PlayAudioClipInChannel with the channel set to LoopinChannel. Play given clip.")]
	public class PlayMusicClip : FsmStateAction
	{
		[RequiredField] [ObjectType(typeof(AudioClip))] public FsmObject AudioClip;
		[HasFloatSlider(0, 1)] public FsmFloat Volume;

		public override void Reset()
		{
			AudioClip = null;
			Volume = 1;
		}

		public override void OnEnter()
		{
		    if (AudioClip.Value == null)
		        Debug.LogWarning("Could not find audio in " + Fsm.Name);
            else
			    AudioManager.Instance.PlayMusic(AudioClip.Value as AudioClip, Volume.Value);
			Finish();
		}

	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Play given audio clip in the given channel. " +
			 "Instruction channel allows only 1 audio to play at a time and will set the Timeout audio. " +
			 "LoopingSound channel is good for background music because the audio will loop, and you can play as many tunes as you like. " +
			 "plus the F8 interrupt has no effect on this channel. " +
			 "SingleSound channel allows only 1 audio to play at a time, but will not set the Timeout audio. " +
			 "MultiSound channel allows for many audios to play at a time, but audios are unique, " +
			 "meaning if you try to play the same sound twice at the same time, it will only play once, and no Timeout audio is set.")]
	public class PlayAudioClipInChannel : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		public FsmObject AudioClip;

		[HasFloatSlider(0, 1)]
		public FsmFloat Volume = 1;

		[HasFloatSlider(-3, 3)]
		public FsmFloat Pitch  = 1;

		[RequiredField]
		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Wait for the audio to finish playing. The music channel will not honor this.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		[Tooltip("Event to call on audio completion.")]
		public FsmEvent OnAudioComplete;

		public override void Reset()
		{
			AudioClip = null;
			Volume = 1;
			Pitch = 1;
			Channel = null;
			Optional = false;
			WaitForCompletion = true;
			OnAudioComplete = null;
		}

		public override void OnEnter()
		{
			if (AudioClip.Value == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				WaitThenFinish(); // PS - you have problems
				return;
			}
			if (WaitForCompletion.Value && (AudioChannel)Channel.Value != AudioChannel.LoopingSound)
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip,
					(AudioChannel)Channel.Value, Volume.Value, WaitThenFinish, pitch: Pitch.Value);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip,
					(AudioChannel)Channel.Value, Volume.Value, OnFinishEvent, pitch: Pitch.Value);
				Finish();
			}
		}

		private void WaitThenFinish()
		{
			OnFinishEvent();
			Finish();
		}

		private void OnFinishEvent()
		{
			Fsm.Event(OnAudioComplete);
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Highlight an object, play an audio clip in the given channel then unhighlight the object.")]
	public class PlayAudioClipWithHighlight : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		public FsmObject AudioClip;

		[HasFloatSlider(0, 1)]
		public FsmFloat Volume;

		[RequiredField]
		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Wait for the audio to finish playing. The music channel will not honor this.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		[Tooltip("Event to call on audio completion.")]
		public FsmEvent OnAudioComplete;

		[RequiredField]
		[Tooltip("Object where the renderer will change color.")]
		public FsmGameObject ObjectToHighlight;

		[RequiredField]
		[Tooltip("What kind of highlight do you want?")]
		[ObjectType(typeof(Effects.Highlight.HighlightBehavior))]
		public FsmEnum HighlightType;

		[Tooltip("What color should we use to highlight this object?")]
		public FsmColor HighlightColor = Color.cyan;

		public override void Reset()
		{
			AudioClip = null;
			Volume = 1;
			Channel = null;
			Optional = false;
			WaitForCompletion = true;
			OnAudioComplete = null;
			ObjectToHighlight = null;
			HighlightColor.Value = Color.cyan;
		}

		public override void OnEnter()
		{
			if (AudioClip.Value == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				SendAudioCompleteEvent();
				Finish();
				return;
			}
			
			Highlight();

			AudioManager.Instance.PlayAudioOnChannel(AudioClip.Value as AudioClip, (AudioChannel)Channel.Value, Volume.Value, Unhighlight);

			if (!WaitForCompletion.Value || (AudioChannel)Channel.Value == AudioChannel.LoopingSound)
			{
				Finish();
			}
		}

		private void SendAudioCompleteEvent()
		{
			Fsm.Event(OnAudioComplete);
		}

		public void Highlight()
		{
			if (ObjectToHighlight.Value != null)
			{
					Effects.Highlight.HighlightObject((Effects.Highlight.HighlightBehavior) HighlightType.Value,
					ObjectToHighlight.Value, false, HighlightColor.Value);
			}
		}

		private void Unhighlight()
		{
			if (ObjectToHighlight.Value != null)
			{
				Effects.Unhighlight.UnhighlightObject(ObjectToHighlight.Value, false);
			}

			SendAudioCompleteEvent();

			if (WaitForCompletion.Value && (AudioChannel) Channel.Value != AudioChannel.LoopingSound)
			{
				Finish();
			}
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Will stop all audio on the specified channel.")]
	public class StopAudioInChannel : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The channel to stop the audio on")]
		[ObjectType(typeof(AudioChannel))]
		public FsmEnum Channel;

		public override void OnEnter()
		{
			Debug.LogFormat("Stopping *ALL* audio on channel {0}", Channel.Value);
			AudioManager.Instance.StopAudioClipOnChannel((AudioChannel)Channel.Value);
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Pauses all audio in the LoopingSound channel.")]
	public class PauseMusic : FsmStateAction
	{

		public override void OnEnter()
		{
			AudioManager.Instance.PauseMusic();
			Finish();
		}

	}

	[ActionCategory("IL-Audio")]
	[Tooltip("UnPauses all audio in the LoopingSound channel.")]
	public class UnPauseMusic : FsmStateAction
	{

		public override void OnEnter()
		{
			AudioManager.Instance.ResumeMusic();
			Finish();
		}

	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Stops all audio in the LoopingSound channel.")]
	public class StopMusic : FsmStateAction
	{

		public override void OnEnter()
		{
			AudioManager.Instance.StopMusic();
			Finish();
		}

	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Basically a way to associate multiple audio clips to a game object")]
	public class AddAudioClipsToGameObject : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("And the award for multiple audios goes to...")]
		public FsmGameObject GameObject;

		[Tooltip("Clear clips from object, then add.")]
		public FsmBool ClearThenAdd;

		[RequiredField]
		[Tooltip("Feel free to add a plethora of audio clips.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject[] AudioClips;


		public override void Reset()
		{
			GameObject = null;
			AudioClips = null;
		}

		public override void OnEnter()
		{
			var interactiveAudio = GameObject.Value.GetOrAddComponent<InteractiveAudio>();
			if (ClearThenAdd.Value)
			{
				interactiveAudio.AudioClips.Clear();
			}
			foreach (var audioClip in AudioClips)
			{
				if (audioClip.Value != null)
					interactiveAudio.AudioClips.Add((AudioClip)audioClip.Value);
			}
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Plays the audio clip added to the Game object form the AddAudioClipsToGameObject")]
	public class PlayAudioClipsFromGameObject : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("Object with with multitudinous audios.")]
		public FsmGameObject GameObject;
		[HasFloatSlider(0, 1)]
		[Tooltip("Sets the volume of the played audio.")]
		public FsmFloat Volume;
		[Tooltip("Keeps the FSM in the current state until the audio finishes playing.")]
		public FsmBool WaitForCompletion;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		public override void Reset()
		{
			GameObject = null;
			Volume = 1;
			WaitForCompletion = true;
			Channel = null;
		}

		public override void OnEnter()
		{
			var interactiveAudios = GameObject.Value.GetComponent<InteractiveAudio>();
			if (interactiveAudios == null)
			{
				Debug.LogWarning("No InteractiveAudios have been added to " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}
			if (WaitForCompletion.Value)
				AudioManager.Instance.PlayAudioOnChannel(interactiveAudios.AudioClips, (AudioChannel) Channel.Value, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(interactiveAudios.AudioClips, (AudioChannel) Channel.Value, Volume.Value);
				Finish();
			}
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("A way to change the interaction state on an Interactive Audio component.")]
	public class SetInteractiveAudioMode : FsmStateAction
	{
		[RequiredField]
		public FsmGameObject GameObject;

		public InteractionStates InteractionState;

		[Tooltip("Recursively set all interaction states.")]
		public FsmBool Recursive;

		public override void Reset()
		{
			GameObject = null;
			InteractionState = InteractionStates.PointerClick;
			Recursive = true;
		}

		public override void OnEnter()
		{
			if (Recursive.Value)
			{
				var iaList = GameObject.Value.GetComponentsInChildren<InteractiveAudio>();

				for (int i = 0; i < iaList.Length; i++)
				{
					iaList[i].InteractionMode = InteractionState;
				}
			}
			else
			{
				var interactiveAudio = GameObject.Value.GetComponent<InteractiveAudio>();

				if (interactiveAudio != null)
				{
					interactiveAudio.InteractionMode = InteractionState;
				}
			}

			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Get's the audio clips associated with the game object.")]
	public class GetAudiosFromGameObject : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("GameObject that where audio has been added.")]
		public FsmGameObject GameObject;
		
		[RequiredField]
		[Tooltip("Array to store the associated audio in.")]
		[ArrayEditor(typeof(AudioClip))]
		public FsmArray StoreResult;

		public override void Reset()
		{
			GameObject = null;
			StoreResult = null;
		}

		public override void OnEnter()
		{
			var interactiveAudio = GameObject.Value.GetComponent<InteractiveAudio>();
			if (interactiveAudio == null)
			{
				Debug.LogWarning("There is no audio associated with this game object");
				Finish();
				return;
			}
			StoreResult.Values = interactiveAudio.AudioClips.ToArray();
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Replays the last audio sequence played in the Instruction channel.")]
	public class ReplayLastInstruction : FsmStateAction
	{
		[Tooltip("Keeps the FSM in the current state until the audio finishes playing.")]
		public FsmBool WaitForCompletion;

		public override void Reset()
		{
			WaitForCompletion = true;
		}
		public override void OnEnter()
		{
			if (WaitForCompletion.Value)
				AudioManager.Instance.PlayAudioOnChannel(AudioManager.Instance.TimeoutAudio, AudioChannel.Instruction, callback: Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(AudioManager.Instance.TimeoutAudio, AudioChannel.Instruction);
				Finish();
			}
		}
	}

    [ActionCategory("IL-Audio")]
    [Tooltip("Retrieve list of cue point times.")]
    public class GetCuePointTimes : FsmStateAction
    {
        [RequiredField]
        [Tooltip("The json file that contains the cue point information")]
        [ObjectType(typeof(TextAsset))]
        public FsmObject CuePointJson;

        [RequiredField]
        [Tooltip("Return the list of times from the cue point JSON")]
        [UIHint(UIHint.Variable)]
        [ArrayEditor(VariableType.Float)]
        public FsmArray CuePointArray;

        public override void Reset()
        {
            CuePointJson = null;
            CuePointArray = null;
        }

        public override void OnEnter()
        {
            var cues = JsonUtility.FromJson<Cue>((CuePointJson.Value as TextAsset).text).cues;
            var times = cues.Select(c => c.Time as object).ToArray();
            CuePointArray.Values = times;
            Finish();
        }
    }

	[ActionCategory("IL-Audio")]
	[Tooltip("Clears the cuepoint highlighter word count.")]
	public class ResetCuepointHighlighterWordCount : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The cuepoint highlighter component")]
		[ObjectType(typeof(CuePointHighlighter))]
		public FsmObject CuePointHighlighter;
		
		public override void Reset()
		{
			CuePointHighlighter = null;
		}

		public override void OnEnter()
		{
			var highlighter = CuePointHighlighter.Value as CuePointHighlighter;
			highlighter.ClearWordCounts();
			Finish();
		}
	}

	[ActionCategory("IL-Audio")]
	[Tooltip("Advances the sequential word index for cuepoint highlighting.")]
	public class AdvanceSequentialWordIndex : FsmStateAction
	{
		[RequiredField]
		[Tooltip("The cuepoint highlighter component")]
		[ObjectType(typeof(CuePointHighlighter))]
		public FsmObject CuePointHighlighter;

		[RequiredField]
		[Tooltip("The amount to advance")]
		public FsmInt Amount;

		public override void Reset()
		{
			CuePointHighlighter = null;
			Amount = 0;
		}

		public override void OnEnter()
		{
			var highlighter = CuePointHighlighter.Value as CuePointHighlighter;
			highlighter.AdvanceSequentialWordIndex(Amount.Value);
			Finish();
		}
	}

	[Obsolete("Deprecated - use 'interactive audio' component and actions")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Associates audio with the game object and will play if one of the actions is selected.")]
	public class AssociateAudioWithGameObject : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("Object with the Clickable component.")]
		public FsmGameObject GameObject;

		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		[Tooltip("Audio clip to associate with the GameObject.")]
		public FsmObject AudioClip;

		[ObjectType(typeof(InteractionStates))]
		[HutongGames.PlayMaker.Tooltip("Choose the operation to trigger playback of the audio.")]
		public FsmEnum Mode;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Stop all audio on click?")]
		public FsmBool StopAllAudioOnClick;

		public override void Reset()
		{
			GameObject = null;
			Mode = InteractionStates.PointerClick;
			Channel = AudioChannel.SingleSound;
			StopAllAudioOnClick = false;
		}

		public override void OnEnter()
		{
			var playAudioOnClick = GameObject.Value.GetOrAddComponent<PlayAudioOnClick>();
			playAudioOnClick.AudioClip = AudioClip.Value == null ? new AudioClip() : (AudioClip)AudioClip.Value;
			playAudioOnClick.Mode = (InteractionStates)Mode.Value;
			playAudioOnClick.Channel = (AudioChannel)Channel.Value;
			playAudioOnClick.StopAllAudioOnClick = StopAllAudioOnClick.Value;

			Finish();
		}
	}

	[Obsolete("Deprecated - use 'interactive audio' component and actions")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Associates audios with the game objects and will play if one of the actions is selected.")]
	public class AssociateAudiosWithGameObjects : FsmStateAction
	{
		[RequiredField]
		[Tooltip("A list of game objects with Clickable component")]
		[ArrayEditor(VariableType.GameObject)]
		public FsmArray GameObjects;

		[RequiredField]
		[Tooltip("A list of audio clips to associate with the game objects")]
		[ArrayEditor(typeof(AudioClip))]
		public FsmArray AudioClips;

		[ObjectType(typeof(InteractionStates))]
		[HutongGames.PlayMaker.Tooltip("Choose the operation to trigger playback of the audio.")]
		public FsmEnum Mode;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Stop all audio on click?")]
		public FsmBool StopAllAudioOnClick;

		public override void Reset()
		{
			GameObjects = null;
			Mode = InteractionStates.PointerClick;
			Channel = AudioChannel.SingleSound;
			StopAllAudioOnClick = false;
		}

		public override void OnEnter()
		{
			if (GameObjects.Values.Length != AudioClips.Values.Length)
			{
				Debug.LogError("array lengths do not match!");
				Finish();
				return;
			}

			for (var i = 0; i < GameObjects.Values.Length; i++)
			{
				var playAudioOnClick = ((GameObject) GameObjects.Values[i]).GetOrAddComponent<PlayAudioOnClick>();
				playAudioOnClick.AudioClip = AudioClips.Values[i] == null ? new AudioClip() : (AudioClip) AudioClips.Values[i];
				playAudioOnClick.Mode = (InteractionStates)Mode.Value;
				playAudioOnClick.Channel = (AudioChannel)Channel.Value;
				playAudioOnClick.StopAllAudioOnClick = StopAllAudioOnClick.Value;

			}

			Finish();
		}
	}

	[Obsolete("Deprecated - use 'interactive audio' component and actions")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Plays the audio clip associated with the Game object.")]
	public class PlayAssociatedAudio : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[HutongGames.PlayMaker.Tooltip("Object with the Clickable component.")]
		public FsmGameObject GameObject;
		[HasFloatSlider(0, 1)]
		[HutongGames.PlayMaker.Tooltip("Sets the volume of the played audio.")]
		public FsmFloat Volume;
		[HutongGames.PlayMaker.Tooltip("Keeps the FSM in the current state until the audio finishes playing.")]
		public FsmBool WaitForCompletion;

		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		public override void Reset()
		{
			GameObject = null;
			Volume = 1;
			WaitForCompletion = true;
		}

		public override void OnEnter()
		{
			var playAudioOnClick = GameObject.Value.GetComponents<PlayAudioOnClick>();
			if (playAudioOnClick.Length == 0 || playAudioOnClick.All(a=>a.AudioClip == null))
			{
				if (!Optional.Value)
				{
					Debug.LogWarning("Could not find audio clip in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				}
				Finish();
				return;
			}
			List<AudioClip> clips = playAudioOnClick.Select(clip => clip.AudioClip).ToList();
			if (WaitForCompletion.Value)
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(clips, (AudioChannel)Channel.Value, Volume.Value);
				Finish();
			}
		}
	}

	[Obsolete("Deprecated - use 'interactive audio' component and actions")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Get's the audio clip associated with the game object (from the AssociateAudioWithGameObject action).")]
	public class GetAssociatedAudio : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("GameObject that has audio associated with it.")]
		public FsmGameObject GameObject;

		[RequiredField]
		[UIHint(UIHint.Variable)]
		[Tooltip("Object to store the associated audio in.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject StoreResult;

		public override void Reset()
		{
			GameObject = null;
		}

		public override void OnEnter()
		{
			var playAudioOnClick = GameObject.Value.GetComponent<PlayAudioOnClick>();
			if (playAudioOnClick == null)
			{
				Debug.LogWarning("There is no audio associated with this game object");
				Finish();
				return;
			}
			StoreResult.Value = playAudioOnClick.AudioClip;

			Finish();
		}
	}

	[ActionCategory("IL-Text")]
	[Tooltip("Sets the audioClip in a Playmaker AudioClip variable.")]
	public class SetAudioClip : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(AudioClip))]
		[Tooltip("The target audio clip variable will be set to this audio clip.")]
		public FsmObject Source;

		[RequiredField]
		[ObjectType(typeof(AudioClip))]
        [UIHint(UIHint.Variable)]
		[Tooltip("Audio clip variable that will be set to the Source audio clip.")]
		public FsmObject Target;

		
		public override void Reset()
		{
			Source = null;
			Target = null;
		}

		public override void OnEnter()
		{
			if (Target.IsNone)
			{
				// Target must be a variable
				Debug.LogWarning("The target variable is not specified.");
				Finish();
				return;
			}

			Target.Value = Source.Value;
			Finish();
		}
	}

	[ActionCategory("IL-Text")]
	[Tooltip("Sets the TimeoutTimer to audio length(optional) + time(optional).")]
	public class SetTimeoutTime : FsmStateAction
	{
		[ObjectType(typeof(AudioClip))]
		[Tooltip("Audio clip to use length as timeout for")]
		public FsmObject Audio;
		[Tooltip("Add an extra X to the time out time.")]
		public FsmFloat ExtraWait;
		[Tooltip("Add DEFAULT TIME OUT time (15seconds)")]
		public FsmBool AddDefaultTime;

		public override void Reset()
		{
			Audio = null;
			ExtraWait = 0;
			AddDefaultTime = false;
		}

		public override void OnEnter()
		{
			var timeoutTime = 0f;
			if (Audio.Value != null)
			{
				timeoutTime += ((AudioClip) Audio.Value).length;
			}
			timeoutTime += ExtraWait.Value;
			if (AddDefaultTime.Value)
				timeoutTime += TimerManager.DEFAULT_TIMEOUT_TIME;
			TimerManager.Instance.TimeoutTime = timeoutTime;
			Finish();
		}
	}


    [ActionCategory("IL-Audio")]
    [HutongGames.PlayMaker.TooltipAttribute("Starts or Stops LipSyncing.")]
    public class SpriteLipSyncing : FsmStateAction
    {
        [HutongGames.PlayMaker.Tooltip("Object must have the 'SpiteLipSync' component attached and setup.")]
        [RequiredField]
        public FsmGameObject LipSyncObject;

        [HutongGames.PlayMaker.Tooltip("Turn lipsync on/off. If ON, will attempt to automatically lip sync to audio played in the 'Instruction' or 'Single' audio channels. Does not work with other audio channels.")]
        public FsmBool LipSyncEnabled;

        public override void Reset()
        {
            LipSyncObject = null;
            LipSyncEnabled = true;
        }

        public override void OnEnter()
        {
            SpriteLipSync component = LipSyncObject.Value.GetComponent<SpriteLipSync>();
            if (component)
                component.SetSource(LipSyncEnabled.Value ? AudioManager.Instance.InstructionAndSingleSource : null);

            Finish();
        }
    }

	#region Obsolete actions
	[Obsolete("Deprecated - use the newer audio things")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Play a given clip with language support options. " +
			 "Instruction channel allows only 1 audio to play at a time and will set the Timeout audio. " +
			 "LoopingSound channel is good for background music because the audio will loop, and you can play as many tunes as you like. " +
			 "plus the F8 interrupt has no effect on this channel. " +
			 "SingleSound channel allows only 1 audio to play at a time, but will not set the Timeout audio. " +
			 "MultiSound channel allows for many audios to play at a time, but audios are unique, " +
			 "meaning if you try to play the same sound twice at the same time, it will only play once, and no Timeout audio is set.")]
	public class PlayLanguageSpecificAudioInChannel : FsmStateAction
	{
		[RequiredField]
		[Tooltip("Audio clip in the student's first or native language (L1).")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject L1AudioClip;

		[RequiredField]
		[Tooltip("Audio clip in the student second language (L2). Almost always this clip will be in English.")]
		[ObjectType(typeof(AudioClip))]
		public FsmObject L2AudioClip;

		[RequiredField]
		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Wait for the audio to finish playing. The music channel will not honor this.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		[Tooltip("If true, always play the L1 audio if not null")]
		public FsmBool ForceL1;

		public override void Reset()
		{
			L1AudioClip = null;
			L2AudioClip = null;
			Optional = false;
			WaitForCompletion = true;
			ForceL1 = false;
		}

		public override void OnEnter()
		{
			if (L1AudioClip.Value == null && L2AudioClip.Value == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}
			var clip1 = new[] { L1AudioClip.Value as AudioClip };
			var clip2 = new[] { L2AudioClip.Value as AudioClip };
			if (WaitForCompletion.Value && (AudioChannel)Channel.Value != AudioChannel.LoopingSound)
				AudioManager.Instance.PlayLanguageAudio(clip1, clip2, (AudioChannel)Channel.Value, ForceL1.Value, Finish);
			else
			{
				AudioManager.Instance.PlayLanguageAudio(clip1, clip2, (AudioChannel)Channel.Value, ForceL1.Value);
				Finish();
			}
		}
	}

	[Obsolete("Deprecated - use the newer audio things")]
	[ActionCategory("IL-Audio")]
	[Tooltip("Plays the audio clip associated with the Game object in the specified channel. " +
			 "Instruction channel allows only 1 audio to play at a time and will set the Timeout audio. " +
			 "LoopingSound channel is good for background music because the audio will loop, and you can play as many tunes as you like. " +
			 "plus the F8 interrupt has no effect on this channel. " +
			 "SingleSound channel allows only 1 audio to play at a time, but will not set the Timeout audio. " +
			 "MultiSound channel allows for many audios to play at a time, but audios are unique, " +
			 "meaning if you try to play the same sound twice at the same time, it will only play once, and no Timeout audio is set.")]
	public class PlayAssociatedAudioInChannel : FsmStateAction
	{
		[RequiredField]
		[ObjectType(typeof(GameObject))]
		[Tooltip("Object with the Clickable component.")]
		public FsmGameObject GameObject;

		[HasFloatSlider(0, 1)]
		[Tooltip("Sets the volume of the played audio.")]
		public FsmFloat Volume;

		[RequiredField]
		[ObjectType(typeof(AudioChannel))]
		[Tooltip("The channel the audio will be played on.")]
		public FsmEnum Channel;

		[Tooltip("Wait for the audio to finish playing. The music channel will not honor this.")]
		public FsmBool WaitForCompletion;

		[Tooltip("Do not log an error if clip not found.")]
		public FsmBool Optional;

		public override void Reset()
		{
			GameObject = null;
			Volume = 1;
			WaitForCompletion = true;
			Optional = false;
		}

		public override void OnEnter()
		{
			var playAudioOnClick = GameObject.Value.GetComponent<PlayAudioOnClick>();
			if (playAudioOnClick == null || playAudioOnClick.AudioClip == null)
			{
				if (!Optional.Value)
					Debug.LogWarning("Could not find audio clip in " + Fsm.Name + " (" + Fsm.ActiveState.Name + ")");
				Finish();
				return;
			}
			if (WaitForCompletion.Value && (AudioChannel)Channel.Value != AudioChannel.LoopingSound)
				AudioManager.Instance.PlayAudioOnChannel(playAudioOnClick.AudioClip, (AudioChannel)Channel.Value, Volume.Value, Finish);
			else
			{
				AudioManager.Instance.PlayAudioOnChannel(playAudioOnClick.AudioClip, (AudioChannel)Channel.Value, Volume.Value);
				Finish();
			}
		}
	}

	#endregion
}